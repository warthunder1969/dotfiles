[Appearance]
ColorScheme=MonokaiKonsole
TabColor=20,22,24,0

[General]
Name=Warthunder
Parent=FALLBACK/
